#!/bin/bash
# desarrollado por isntzero

rm -f setup.bash # <--- borra el setup.bash
clear #<--- limpia la pantalla

cowsay -f dragon "Hola, soy dragon_find, rawr!, una herramienta de búsqueda de palabras claves en archivos de texto, desarrollada por isntzero" | lolcat
echo "\nSolo sigue las instrucciones que yo me encargo,rawr!"
echo "\n----------------------------------------------------"
echo -n "Nombre del archivo [$] : " | lolcat && read nombre_archivo
echo -n "Palabra clave [$] : " | lolcat && read dato_archivo
echo -n "Nombre del archivo donde se guardará [$] : " | lolcat && read expo_archivo

# Verifica si el archivo existe en el directorio actual
if [ -f "./$nombre_archivo" ]; then
  grep -n -i "$dato_archivo" "./$nombre_archivo" > "$expo_archivo.txt" && clear && cowsay -f dragon "Datos encontrados y almacenados en $expo_archivo.txt" | lolcat
else
  clear
  cowsay -f dragon "Oye, algo anda mal, revisa el readme.txt" | lolcat
fi  

echo -n "Deseas continuar? [y-n]: " | lolcat && read respuesta

if [ "$respuesta" = "y" ]; then  # Corregir el uso de corchetes
  clear
  sh dragonfind.sh
elif [ "$respuesta" = "n" ]; then  # Corregir el uso de corchetes
  clear
  cowsay -f dragon "Nos vemos, rawr!, desarrollada por @isntzero" | lolcat
else
  clear
  cowsay -f dragon "Vuelve a intentarlo, rawr!, desarrollada por @isntzero" | lolcat
fi