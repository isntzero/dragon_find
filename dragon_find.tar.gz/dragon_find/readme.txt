Para que leer el archivo deberas colocar el archivo en la misma carpeta que el script.

Luego solo deberas colocar el nombre del archivo.
Colocar el dato que deseas buscar en el archivo.
Y despues colocar el nombre del archivo de texto donde se exportaran los datos encontrados.

Diviertete,
isntzero